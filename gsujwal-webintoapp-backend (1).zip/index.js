const express = require('express');
const multer = require('multer');
const unzipper = require('unzipper');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

app.use('/public', express.static(path.join(__dirname, 'public')));

const storage = multer.diskStorage({
  destination: 'uploads/',
  filename: (req, file, cb) => cb(null, Date.now() + '-' + file.originalname)
});
const upload = multer({ storage });

app.post('/upload', upload.single('file'), async (req, res) => {
  const file = req.file;
  if (!file) return res.status(400).send('No file uploaded.');

  const folder = `public/site-${Date.now()}`;
  fs.mkdirSync(folder, { recursive: true });

  if (file.mimetype === 'application/zip') {
    fs.createReadStream(file.path)
      .pipe(unzipper.Extract({ path: folder }))
      .on('close', () => {
        const url = `${req.protocol}://${req.get('host')}/${folder.replace('public/', '')}/index.html`;
        res.send({ url });
      });
  } else if (file.mimetype === 'text/html') {
    fs.renameSync(file.path, `${folder}/index.html`);
    const url = `${req.protocol}://${req.get('host')}/${folder.replace('public/', '')}/index.html`;
    res.send({ url });
  } else {
    res.status(400).send('Only ZIP or HTML files are supported.');
  }
});

app.listen(PORT, () => {
  console.log(`✅ Server running at http://localhost:${PORT}`);
});
